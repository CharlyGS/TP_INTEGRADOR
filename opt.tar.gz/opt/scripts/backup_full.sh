show_help() {
    echo "======================================================"
    echo "  AYUDA - SCRIPT DE BACKUP AUTOMATIZADO (TPServer)"
    echo "======================================================"
    echo ""
    echo "DESCRIPCIÓN:"
    echo "  Realiza backups comprimidos en formato .tar.gz de un directorio"
    echo "  de origen a un directorio de destino."
    echo ""
    echo "USO:"
    echo "  $0 <directorio_origen> <directorio_destino>"
    echo ""
    echo "PARÁMETROS:"
    echo "  directorio_origen     Ruta completa del directorio a respaldar."
    echo "  directorio_destino    Ruta donde se almacenará el backup."
    echo ""
    echo "OPCIONES:"
    echo "  -h, --help            Muestra este menú de ayuda."
    echo ""
    echo "EJEMPLOS DE USO:"
    echo "  $0 /var/log /backup_dir"
    echo "  $0 /www_dir /backup_dir"
    echo ""
    echo "FORMATO DEL ARCHIVO DE SALIDA:"
    echo "  El nombre del archivo generado será: [nombre_origen]_bkp_YYYYMMDD.tar.gz"
    echo "  Ejemplo: log_bkp_20250615.tar.gz"
    echo ""
    echo "AUTOMATIZACIÓN (CRON):"
    echo "  - /var/log:  Todos los días a las 00:00 hs."
    echo "  - /www_dir:  Lunes, Miércoles y Viernes a las 23:00 hs."
    echo "======================================================"
    exit 0
}

if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    show_help
fi

if [ "$#" -ne 2 ]; then
    echo "Error: Número incorrecto de argumentos." >&2
    echo "Uso: $0 <directorio_origen> <directorio_destino>" >&2
    echo "Para más información, use la opción -h o --help." >&2
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_BACKUP="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"
HORA=$(date +'%H:%M:%S')

echo "--- [$(date +'%d-%m-%Y %H:%M:%S')] INICIANDO SCRIPT DE BACKUP ---"
echo "Validando parámetros..."

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe." >&2
    logger -t backup_script "ERROR: Origen $ORIGEN no encontrado."
    exit 1
fi
if [ ! -r "$ORIGEN" ]; then
    echo "Error: No se tienen permisos de lectura sobre el origen '$ORIGEN'." >&2
    logger -t backup_script "ERROR: Sin permisos de lectura en $ORIGEN."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe." >&2
    logger -t backup_script "ERROR: Destino $DESTINO no encontrado."
    exit 1
fi
if [ ! -w "$DESTINO" ]; then
    echo "Error: No se tienen permisos de escritura sobre el destino '$DESTINO'." >&2
    logger -t backup_script "ERROR: Sin permisos de escritura en $DESTINO."
    exit 1
fi

echo "Validaciones completadas exitosamente."

echo ""
echo "---------------------------------"
echo "  INFORMACIÓN DEL BACKUP"
echo "---------------------------------"
echo "  - Origen:    $ORIGEN"
echo "  - Destino:   $ARCHIVO_BACKUP"
echo "  - Fecha:     $(date +'%d/%m/%Y')"
echo "  - Hora:      $HORA"
echo "  - Usuario:   $(whoami)"
echo "  - Host:      $(hostname)"
echo "---------------------------------"
echo ""

echo "Iniciando compresión de '$ORIGEN'..."
INICIO_TS=$(date +%s)

tar -czf "$ARCHIVO_BACKUP" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

if [ $? -eq 0 ]; then
    FIN_TS=$(date +%s)
    DURACION=$((FIN_TS - INICIO_TS))
    TAMANO_BKP=$(du -h "$ARCHIVO_BACKUP" | cut -f1)

    echo ""
    echo "¡BACKUP COMPLETADO CON ÉXITO!"
    echo "  - Archivo generado: $ARCHIVO_BACKUP"
    echo "  - Tamaño: $TAMANO_BKP"
    echo "  - Duración: ${DURACION} segundos."

    logger -t backup_script "SUCCESS: Backup de $ORIGEN creado en $ARCHIVO_BACKUP ($TAMANO_BKP)."
    
    echo "--- [$(date +'%d-%m-%Y %H:%M:%S')] FIN DEL SCRIPT ---"
    exit 0
else
    echo "Error: Falló el comando 'tar' durante la compresión." >&2
    # Si el archivo de backup se creó parcialmente, se elimina para no dejar basura.
    [ -f "$ARCHIVO_BACKUP" ] && rm -f "$ARCHIVO_BACKUP"
    logger -t backup_script "FATAL: Fallo al comprimir $ORIGEN."
    echo "--- [$(date +'%d-%m-%Y %H:%M:%S')] FIN DEL SCRIPT CON ERRORES ---"
    exit 1
fi
